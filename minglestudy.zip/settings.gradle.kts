rootProject.name = "minglestudy"
